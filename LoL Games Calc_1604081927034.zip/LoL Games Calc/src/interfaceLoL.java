interface interfaceLol {


//vars for each rank (Static ints) for lp needed from iron 4
//current player rank and lp ( ex: plat 3 60 lp )
//input lp gain and loss. ex: +19, -16
//goal rank ex: diamond 4
// take into account promo wins / loses
// below plat 4 you get extra help on wins
// take into account average win rate ex: 56%
//Iron 4 = 0 LP
//Iron 3 = 100 LP
//Iron 2 = 200 LP
//Iron 1 = 300 LP
//Bronze 4 = 400 LP
//Bronze 3 = 500 LP
//Bronze 2 = 600 LP
//Bronze 1 = 700 LP
//Silver 4 = 800 LP
//Silver 3 = 900 LP
//Silver 2 = 1000 LP
//Silver 1 = 1100 LP
//Gold 4 = 1200 LP
//Gold 3 = 1300 LP
//Gold 2 = 1400 LP
//Gold 1 = 1500 LP
//Platinum 4 = 1600 LP
//Platinum 3 = 1700 LP
//Platinum 2 = 1800 LP
//Platinum 1 = 1900 LP
//Diamond 4 = 2000 LP
//Diamond 3 = 2100 LP
//Diamond 2 = 2200 LP
//Diamond 1 = 2300 LP
//-----------------
// if below 1600 lp, get +1 free win in promos
// +2 wins needed for interdivisional promos
// +3 wins needed for divisional promos
// games needed rounded up ex , have to go over 100lp to get to promos






















} 